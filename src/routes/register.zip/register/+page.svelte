<script>
	let username = "";
	let password = "";
	let confirmpassword = "";

	const FetchData = async () => {
		console.log("register")
		console.log("username:",username)
		let config = {
			method: 'POST',
			headers: {
				'Access-Control-Allow-Origin': '*',
				'Content-Type': 'application/json',
				'token': ''
			},
			body: JSON.stringify({
				username: username,
				password: password
			})
		};
		var result = await fetch(`https://4be1-2001-fb1-10d-89f-1cea-a42f-1b93-4189.ngrok-free.app/api/login`, config);
	};
</script>
<svelte:head>
	<title>About</title>
	<meta name="description" content="About this app" />
</svelte:head>
<div class="w-100 min-vh-100 d-flex align-items-center justify-content-center">
	<div class="row w-100">
		<div class="col-12 col-md-8 col-lg-6 col-xl-4 col-xxl-3 mx-auto">
			<div class="card p-3 shadow">
				<h4 class="text-bold">Register</h4>
				<span class="mb-3">Username</span>
				<input type="text" class="form-control mb-3" bind:value={username}/>
				<span class="mb-3">Password</span>
				<input type="text" class="form-control mb-3" bind:value={password}/>
				<span class="mb-3">Confirm password</span>
				<input type="text" class="form-control mb-3" bind:value={confirmpassword}/>
				<button class="btn btn-primary w-100" on:click={()=>FetchData()}>Register</button>
			</div>
		</div>
	</div>
</div>
